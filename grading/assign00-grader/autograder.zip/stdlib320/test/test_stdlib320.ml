let _ =
  let _ : unit = () in
  print_float (3. /. 0.)
